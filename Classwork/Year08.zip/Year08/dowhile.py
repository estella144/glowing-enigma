# Do while loop - loop and a half

x = 0

while True:
    x += 1
    print(x)
    if x == 69:
        break

print("done")
