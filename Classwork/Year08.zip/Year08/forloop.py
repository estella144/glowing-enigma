for i in range(1,71,2):
    print("Number", i)
