table = int(input("What table do you want?"))
for i in range(1, 11):
    print(f"{i} x {table} = {i*table}")
input()

