a = "hello"
b = "world"
c = a + b
print(c)
